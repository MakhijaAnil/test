 //
//  AppDelegate.swift
//  Exatech
//
//  Created by Anil on 05/03/18.
//  Copyright © 2018 Anil. All rights reserved.
//

import UIKit
 import IQKeyboardManagerSwift
 import ObjectMapper
 import Crashlytics

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        
        sleep(3)
        
       // Fabric.with([Crashlytics.self])
        
        //Setting up of  IQKeyboardManager framework
        IQKeyboardManager.sharedManager().enable = true
        IQKeyboardManager.sharedManager().keyboardDistanceFromTextField = 70
        
        // constraint log stop
        UserDefaults.standard.setValue(false, forKey:"_UIConstraintBasedLayoutLogUnsatisfiable")
        
        // register for push notifications
       // registerForNotifications(application: application)
        
        // setup firebase
       // FirebaseApp.configure()
        
        // setup window
        UIApplication.shared.statusBarStyle = .lightContent
        
        
        
        window?.rootViewController = ScreenManager.getRootViewController()
        window?.makeKeyAndVisible()
        
        // handle if the application was opened using a notification
//        if let notification = launchOptions?[UIApplicationLaunchOptionsKey.remoteNotification] as? [AnyHashable: Any] {
//           // handleNotification(notification)
//        }
        
       // addObserverForRefereshFirebaseToken()
       // addObserverForUserSignInNotification()
        // Override point for customization after application launch.
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }


}
 //MARK:- Deep Linking
 //MARK:-
 
 extension AppDelegate {
    
    func handleDeepLink(deepLink: App.DeepLinks, urlComponents: [String]) {
        
        switch deepLink {
        case .verifyUser:
            if urlComponents.count == 3 {
                if let userId = Int(urlComponents[2]) {
                    // temporarily show launch view
                    let viewController = ViewController()
                    ScreenManager.setAsMainViewController(ScreenManager.embedNavigationController(viewController: viewController))
                   // self.updateProfileAndNavigate(userId: userId)
                    
                }
            }
        case .invite:
            if urlComponents.count == 3 {
                if let refID = Int(urlComponents[2]) {
                    //   temporarily show launch view
                    let viewController = ViewController()
                    ScreenManager.setAsMainViewController(ScreenManager.embedNavigationController(viewController: viewController))
                    
                    let when = DispatchTime.now() + 3 // change 2 to desired number of seconds
                    DispatchQueue.main.asyncAfter(deadline: when) {
                        let viewController = ScreenManager.getMenuViewController()
                       // ScreenManager.refferalID = refID
                        ScreenManager.setAsMainViewController(ScreenManager.embedNavigationController(viewController: viewController))
                    }
                }
            }
        }
    }
 }
 /*
 //MARK:- Web Services
 //MARk:-
 extension AppDelegate {
    
    func updateProfileAndNavigate(userId: Int) {
        
        APIManager.sharedInstance.get(url: App.URLs.profile, parameters: ["user_id":"\(userId)"], headToken: userId, viewController: nil, isLoadingIndicatorShow: false) { (jsonDict) in
            
            if jsonDict.object(forKey: "is_success") as? Bool  == true {
                if let newUser = Mapper<UserModel>().map(JSONObject: jsonDict.value(forKey: "profile")) {
                    UserDefaults.setUser(newUser)
                    
                    if let _ = newUser.id {
                        self.submitDeviceToken()
                    }
                    
                    ScreenManager.setAsMainViewController(ScreenManager.getRootViewController())
                    
                } else {
                }
            } else {
            }
        }
    }
    
    func submitDeviceToken() {
        guard let deviceToken = UserDefaults.getDeviceToken() else {
            return
        }
        
        let params: [String: Any] = [
            "device_token": deviceToken
        ]
        
        APIManager.sharedInstance.post(url: App.URLs.registerDeviceToken, parameters: params, headToken: (UserDefaults.getUser()?.id)!, viewController:nil , isLoadingIndicatorShow: false) { (jsonDict) in
            
            if jsonDict.object(forKey: "is_success") as? Bool  == true {
                print("Token submitted succesfully" )
            } else {
                print("Token submission error")
            }
        }
    }
    
 }*/

