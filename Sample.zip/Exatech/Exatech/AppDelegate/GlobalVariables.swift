//
//  GlobalVariables.swift
//  Exatech
//
//  Created by Anil on 05/03/18.
//  Copyright © 2017 DigiMantra. All rights reserved.
//

import Foundation
import UIKit

class GlobalVariables {
    
    static let sharedInstance = GlobalVariables()
    private init() {}
    
    var isMenuItemSelect = Bool()
    var flag = Bool(false)
    var sessionModel = SessionDetailModel()
    var placeModel = CreatePlaceModel()
}
