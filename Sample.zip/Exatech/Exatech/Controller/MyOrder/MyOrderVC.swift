//
//  MyOrderVC.swift
//  Exatech
//
//  Created by Admin on 05/04/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import UIKit

class MyOrderVC: BaseViewController {

    @IBOutlet weak var OrderTypeCV: UICollectionView!
    var attentionReqlist = [String]()
    var attentionReqlistimg = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        attentionReqlist = ["Inspection Schedule", "New Message", "Profile Incomplete","Profile Incomplete"]
        
        attentionReqlistimg = ["inspection", "message", "ProfileIncompleted","document"]
        // self.AttentionRequiredCV.register(UICollectionView.self, forCellReuseIdentifier: "CustCell")
    //self.OrderTypeCV.register(UINib(nibName: "OrderCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "OrderCollectionViewCell")

        // Do any additional setup after loading the view.
    }
    @IBAction func tapBack(_ sender: Any) {
        _ = navigationController?.popViewController(animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
//MARK:- CollectionView Methods
//MARK:-

extension MyOrderVC: UICollectionViewDataSource{
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int{
        return attentionReqlist.count
    }
    
    
    // The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell{
        //  let cell = UINib(nibName: OrderCollectionViewCell.className, bundle: nil)
        let cell : OrderCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "OrderCollectionViewCell", for: indexPath) as! OrderCollectionViewCell
        // cell.configure(for: indexPath.row)//menuItem: attentionReqlist[indexPath.row]
        cell.LblName.text = attentionReqlist[indexPath.row]
        cell.IcoImg.image = UIImage(named:attentionReqlistimg[indexPath.row])
        //  AttentionRequiredCV.register(cellNib, forCellReuseIdentifier: OrderCollectionViewCell.className)
        // let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath)
        
        return cell
    }
}

extension MyOrderVC: UICollectionViewDelegate{
    
    public func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let objMessageVC = self.storyboard?.instantiateViewController(withIdentifier: "MessageListVC") as! MessageListVC
        self.navigationController?.pushViewController(objMessageVC, animated: true)
        
    }
}


extension MyOrderVC{
    
}
