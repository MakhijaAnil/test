//
//  OrderListVC.swift
//  Exatech
//
//  Created by Anil on 19/03/18.
//  Copyright © 2018 Anil. All rights reserved.
//

import UIKit

class OrderListVC: BaseViewController {

    @IBOutlet weak var tblOrder: UITableView!
    var pageNo:Int=0
    var limit:Int=20
    var offset:Int=0 //pageNo*limit
    var didEndReached:Bool=false
    var isDataLoading:Bool=false

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        
        print("scrollViewWillBeginDragging")
        isDataLoading = false
    }
    
    
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        print("scrollViewDidEndDecelerating")
    }
    //Pagination
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        print("scrollViewDidEndDragging")
        if ((tblOrder.contentOffset.y + tblOrder.frame.size.height) >= tblOrder.contentSize.height)
        {
            if !isDataLoading{
                isDataLoading = true
                self.pageNo=self.pageNo+1
                self.limit=self.limit+10
                self.offset=self.limit * self.pageNo
               // loadCallLogData(offset: self.offset, limit: self.limit)
                
            }
        }
        
        
    }
//    func loadCallLogData(offset:Int, limit:Int  ) -> Int {
//        <#function body#>
//    }

}
extension OrderListVC: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 100;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "OrderHistoryCell", for: indexPath)
        //cell.textLabel?.text = accountlist[indexPath.row]
        
        //        if let cell = cell as? TermsAndConditionsCell {
        //            //cell.configure(forTerms: termsArray[indexPath.row])
        //        }
        
        return cell
        
    }
}

extension OrderListVC : UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        //        let terms = termsArray[indexPath.row]
        //
        //        let viewController = ScreenManager.getTermsAndConditionsDetailViewController()
        //        viewController.terms = terms
        //
        //            let DashbordVC = self.storyboard?.instantiateViewController(withIdentifier: "DashbordVC")
        //            navigationController?.pushViewController(DashbordVC!, animated: true)
    }
}

extension OrderListVC{
    
    
}


