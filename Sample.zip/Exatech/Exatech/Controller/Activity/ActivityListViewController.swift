//
//  ActivityListViewController.swift
//  BTV-Coach
//
//  Created by Vishal on 14/01/17.
//  Copyright © 2017 AppRoots.tech. All rights reserved.
//

import UIKit
import ObjectMapper

class ActivityListViewController: BaseViewController {

    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var noActivityLbl: UILabel!

    var activityList: [ActivityListItemModel] = []
    var filteredActivityList: [ActivityListItemModel] = []
    var sessionRequestFilterParameter = [String:String]()
    var toNavigate = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureTableView()
        callActivityList(parameters: ["host_id":"\(user!.id!)"])
    }
    
    @IBAction func tapBack(_ sender: UIButton) {
        _ = navigationController?.popViewController(animated: true)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        if let selectedIndexPath = tableView.indexPathForSelectedRow {
            tableView.deselectRow(at: selectedIndexPath, animated: true)
        }
    }
}

//MARK:- Custom Method
//MARK:-

extension ActivityListViewController {
    func configureTableView() {
        tableView.dataSource = self
        tableView.delegate = self
        tableView.tableFooterView = UIView()
        tableView.separatorInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)

        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 70.0

//        let cellNib = UINib(nibName: ActivityListCell.className, bundle: nil)
//        tableView.register(cellNib, forCellReuseIdentifier: ActivityListCell.className)
    }
    
}

//MARK:- UISearchBarDelegate
//MARK:-
extension ActivityListViewController: UISearchBarDelegate {
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        self.searchBar(searchBar, textDidChange: "")
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(true, animated: true)
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(false, animated: true)
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        if searchText == "" {
            filteredActivityList = activityList.map { $0 }
            
            if filteredActivityList.count == 0 {
                self.noActivityLbl.text = "No activities available"
            } else {
                self.noActivityLbl.text = ""
            }
            
        } else {
            filteredActivityList = activityList.filter { activityItem in
                if let activityTitle = activityItem.activity.title {
                    return activityTitle.lowercased().contains(searchText.lowercased())
                }
                return false
            }
            
            if filteredActivityList.count == 0 {
                self.noActivityLbl.text = "No matches found"
            } else {
                self.noActivityLbl.text = ""
            }
        }
        
        tableView.reloadData()
    }
}

//MARK:- UITableViewDataSource
//MARK:-

extension ActivityListViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredActivityList.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: ActivityListCell.className, for: indexPath)
//
//        if let cell = cell as? ActivityListCell {
//            let activityListItem = filteredActivityList[indexPath.row]
//            cell.configure(for: activityListItem)
//        }

        return cell
    }
}

//MARK: UITableViewDelegate
//Mark:-

extension ActivityListViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        if toNavigate == "coachList" {
            
            let controller = ScreenManager.getCoachListViewController()
            let activityListItem = filteredActivityList[indexPath.row]
            controller.activity = activityListItem.activity
            navigationController?.pushViewController(controller, animated: true)
            
        } else {
        
            let controller = ScreenManager.getOpenSessionListViewController()
            let activityListItem = filteredActivityList[indexPath.row]
            controller.activity = activityListItem.activity
            
            if toNavigate == "Open Custom Sessions" {
                controller.toNavigate = toNavigate
            } else {
                controller.toNavigate = toNavigate
                controller.sessionRequestFilterParameter = self.sessionRequestFilterParameter
            }
            navigationController?.pushViewController(controller, animated: true)
        }
    }
}

//MARK:- Web Service
//MARK:-
extension ActivityListViewController {
    
    func callActivityList(parameters:[String:String]) {
        
        APIManager.sharedInstance.get(url: App.URLs.hostActivities, parameters: parameters, headToken: user!.id!, viewController: self, isLoadingIndicatorShow: true) { (jsonDict) in
            
            if jsonDict.object(forKey: "is_success") as? Bool  == true {
                
                if let activities = Mapper<ActivityModel>().mapArray(JSONObject: jsonDict.value(forKey: "list")) {
                    if activities.count == 0 {
                        self.noActivityLbl.text = "No activities available"
                    } else {
                        self.activityList = activities.map { activity -> ActivityListItemModel in
                            return ActivityListItemModel(activity: activity, count: 0)
                        }
                        self.noActivityLbl.text = ""
                        self.filteredActivityList = self.activityList.map { $0 }
                        self.tableView.reloadData()
                    }
                   
                } else {
                    self.noActivityLbl.text = "No activities available"
                }
            } else {
                self.noActivityLbl.text = "No activities available"
                
                if let msg = jsonDict.object(forKey: "message") as? String  {
                    if msg == "your accout is not active" {
                        self.showAlertForLogout(title: App.Name, message: "\(jsonDict.object(forKey: "message")!)", viewController: self)
                    }
                }
            }
        }
    }
}
