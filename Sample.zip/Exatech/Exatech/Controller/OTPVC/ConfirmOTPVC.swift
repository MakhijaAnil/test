//
//  ConfirmOTPVC.swift
//  Exatech
//
//  Created by Anil on 09/03/18.
//  Copyright © 2018 Anil. All rights reserved.
//

import UIKit

class ConfirmOTPVC: UIViewController,CodeInputViewDelegate
 {

    override func viewDidLoad() {
        super.viewDidLoad()

        
        let frame = CGRect(x:(view.frame.width-315)/2, y: self.view.frame.height/1.9, width:315, height: 60)
        let codeInputView = CodeInputView(frame:frame)
        codeInputView.delegate = self
        view.addSubview(codeInputView)
        codeInputView.becomeFirstResponder()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
    }
    func codeInputView(_ codeInputView: CodeInputView, didFinishWithCode code: String) {
        let title = (code == "123456" ? "Correct!" : "Wrong!")
        if (title == "Correct!")
        {
            let AccountListVC = self.storyboard?.instantiateViewController(withIdentifier: "AccountListVC") as! AccountListVC
            self.navigationController?.pushViewController(AccountListVC, animated: true)
        }else{
            let alert = UIAlertController(title: title, message: nil, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .cancel) { _ in codeInputView.clear() })
            present(alert, animated: true)
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
