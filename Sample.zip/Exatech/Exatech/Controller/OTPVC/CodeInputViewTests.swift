import XCTest
import CodeInputView

class CodeInputViewTests: XCTestCase {
    func testExample() {

    }
}
