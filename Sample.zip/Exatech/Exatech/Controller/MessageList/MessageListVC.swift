//
//  MessageListVC.swift
//  Exatech
//
//  Created by Admin on 04/04/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import UIKit

class MessageListVC: BaseViewController {
    
    @IBOutlet weak var tblmessage: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.navigationController?.isNavigationBarHidden = false
        self.title = "Messages"
        configureTableView()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func configureTableView() {
        //  tblmessage.tableFooterView = UIView()
        let cellNib = UINib(nibName: MessageTableViewCell.className, bundle: nil)
        tblmessage.register(cellNib, forCellReuseIdentifier: MessageTableViewCell.className)
    }
    
    
    @IBAction func tapBack(_ sender: Any) {
         _ = navigationController?.popViewController(animated: true)
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}

//MARK: - UITableView Delegates Method
//MARK:

extension MessageListVC: UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
}

//MARK: - UITableViewDataSource Methods
//MARK:

extension MessageListVC: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MessageTableViewCell", for: indexPath)
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 60.0
        
    }
    
}

//MARK: - UIButtonEvent Methods
//MARK:

extension MessageListVC{
    
//    @IBAction func tapBack(_ sender: UIButton) {
//        _ = navigationController?.popViewController(animated: true)
//    }
}
