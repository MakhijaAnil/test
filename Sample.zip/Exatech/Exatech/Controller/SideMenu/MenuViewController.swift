//
//  MenuViewController.swift
//  BTV-Ambassador
//
//  Created by Anil on 05/03/18.
//  Copyright © 2017 DigiMantra. All rights reserved.
//

import UIKit
import SDWebImage


class MenuViewController: BaseViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var headerContainer: UIView!
    @IBOutlet weak var footerContainer: UIView!
    @IBOutlet var authorizedHeaderView: UIView!
    
    @IBOutlet var authorizedFooterView: UIView!
    
    @IBOutlet weak var userImageView: CircularImageView!
    @IBOutlet weak var userNameLbl: UILabel!
    @IBOutlet weak var manageProfileBtn: UIButton!
    
    var menuItem = [MenuItemModel]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialLoad()
        configureTableView()
        
        setupHeader()
        setupFooter()
        
        menuItem = MenuItemModel.getMenuItem()
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        initialLoad()
    }
}

//MARK:- Custom Methods
//MARK:-

extension MenuViewController {
    
    func initialLoad() {
        userNameLbl.text = UserDefaults.getUser()?.firstName ?? "Shilesh Lahoti"
        userImageView.image = #imageLiteral(resourceName: "profile")
        //userImageView.sd_setImage(with: URL(string:UserDefaults.getUser()?.profileImage?.completePath ?? ""), placeholderImage: UIImage(named: App.URLs.imagePlaceHolderURL))
    }
    
    func configureTableView() {
        tableView.tableFooterView = UIView()
        let cellNib = UINib(nibName: MenuTableViewCell.className, bundle: nil)
        tableView.register(cellNib, forCellReuseIdentifier: MenuTableViewCell.className)
    }
    
    func setupHeader() {
        authorizedHeaderView.frame = headerContainer.bounds
        headerContainer.addSubview(authorizedHeaderView)
    }
    
    func setupFooter() {
        authorizedFooterView.frame = footerContainer.bounds
        footerContainer.addSubview(authorizedFooterView)
    }
}

//MARK:-  Button Action
//MARK:-

extension MenuViewController {
    
    @IBAction func tapLogout(_ sender: UIButton) {
        
        let alert = UIAlertController(title: App.Name, message: "Do you want to log out?", preferredStyle: .alert)
        
        alert.addAction(
            UIAlertAction(
                title: "Log out",
                style: .default,
                handler: { _ in
                    UserDefaults.clearUserData()
                    ScreenManager.setAsMainViewController(ScreenManager.getRootViewController())
            })
        )
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
        
        present(alert, animated: true, completion: nil)
        
    }
    
    @IBAction func tapManageProfile(_ sender: UIButton) {
        
        let controller = ScreenManager.getDashboardViewController()
        self.navigationController?.pushViewController(controller, animated: true)
        
    }
}

// MARK:- UITableViewDataSource
//MARK:-

extension MenuViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuItem.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let  cell = tableView.dequeueReusableCell(withIdentifier: MenuTableViewCell.className, for: indexPath) as! MenuTableViewCell
        cell.configure(for: indexPath.row, menuItem: menuItem[indexPath.row])
        cell.backgroundColor = UIColor.clear
        return cell
    }
}

// MARK:- UITableViewDelegate
//MARK:-

extension MenuViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        var controller = UIViewController()
        
        GlobalVariables.sharedInstance.isMenuItemSelect = false
        
        switch (indexPath.row) {
        case 0:
            GlobalVariables.sharedInstance.isMenuItemSelect = false
            
            //            if UserDefaults.getUser()?.isActive == 2 {
            //                controller = ScreenManager.getDashboardViewController()
            //            } else {
            //                controller = ScreenManager.getDashboardViewController()
            //            }
            
            controller = ScreenManager.getDashboardViewController()
            self.sideMenuViewController!.setContentViewController(controller, animated: true)
            self.sideMenuViewController!.hideMenuViewController()
            break;
        case 1:
            GlobalVariables.sharedInstance.isMenuItemSelect = false
            controller = ScreenManager.getMyOrderViewController()
            self.sideMenuViewController!.setContentViewController(controller, animated: true)
            self.sideMenuViewController!.hideMenuViewController()
            
            break;
            /*case 2:
             controller = ScreenManager.getDashboardViewControlle()
             GlobalVariables.sharedInstance.isMenuItemSelect = true
             break;
             case 3:
             
             controller = ScreenManager.getDashboardViewControlle()
             
             if let controller = controller as? ActivityListViewController {
             controller.toNavigate = "Open Custom Sessions"
             }
             
             GlobalVariables.sharedInstance.isMenuItemSelect = true
             break;
             case 4:
             controller = ScreenManager.getActivityListViewController()
             
             if let controller = controller as? ActivityListViewController {
             controller.toNavigate = "coachList"
             }
             
             GlobalVariables.sharedInstance.isMenuItemSelect = true
             break;
             case 5:
             controller = ScreenManager.getReportViewController()
             GlobalVariables.sharedInstance.isMenuItemSelect = true
             break;
             case 6:
             controller = ScreenManager.getSettingAndPreferencesViewController()
             GlobalVariables.sharedInstance.isMenuItemSelect = true
             break;
             case 7:
             controller = ScreenManager.getContactSupportViewController()
             GlobalVariables.sharedInstance.isMenuItemSelect = true
             break;*/
        case 2:
            break;
            
        default:
            break;
        }
        
        if  GlobalVariables.sharedInstance.isMenuItemSelect == true {
            self.navigationController?.pushViewController(controller, animated: true)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row < 5 {
            return 60.0
        } else {
            return 45.0
        }
    }
}

