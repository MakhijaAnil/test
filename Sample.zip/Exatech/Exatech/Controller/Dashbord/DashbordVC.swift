//
//  ViewController.swift
//  MDRotatingPieChart
//
//  Created by Maxime DAVID on 2015-04-03.
//  Copyright (c) 2015 Maxime DAVID. All rights reserved.
//

import UIKit
//import ObjectMapper


class DashbordVC:BaseViewController ,MDRotatingPieChartDelegate, MDRotatingPieChartDataSource {
    
    @IBOutlet weak var ItemSearchBar: UISearchBar!
    @IBOutlet weak var AttentionRequiredCV: UICollectionView!
    var attentionReqlist = [String]()
    var attentionReqlistimg = [String]()
    var notificationcout = [String]()
    var backgroundColor = [String]()

    var items = [integer_t]()

    var slicesData:Array<Data> = Array<Data>()
    @IBOutlet weak var disableMenuButton: UIButton!
    
    var pieChart:MDRotatingPieChart!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        initalLoad()
        //configurePieChart()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        refresh()
        // sideMenuViewController?.presentLeftMenuViewController()
        
        //  disableMenuButton.isSelected = !(sideMenuViewController()?.menuContainerView?.allowPanGesture ?? false)
    }
    
    
    
    
    //Delegate
    //some sample messages when actions are triggered (open/close slices)
    func didOpenSliceAtIndex(_ index: Int) {
        print("Open slice at \(index)")
    }
    
    func didCloseSliceAtIndex(_ index: Int) {
        print("Close slice at \(index)")
    }
    
    func willOpenSliceAtIndex(_ index: Int) {
        print("Will open slice at \(index)")
    }
    
    func willCloseSliceAtIndex(_ index: Int) {
        print("Will close slice at \(index)")
    }
    
    //Datasource
    func colorForSliceAtIndex(_ index:Int) -> UIColor {
        return slicesData[index].color
    }
    
    func valueForSliceAtIndex(_ index:Int) -> CGFloat {
        return slicesData[index].value
    }
    
    func labelForSliceAtIndex(_ index:Int) -> String {
        return slicesData[index].label
    }
    
    func numberOfSlices() -> Int {
        return slicesData.count
    }
    
    //    override func viewDidAppear(_ animated: Bool) {
    //        super.viewDidAppear(animated)
    //        refresh()
    //    }
    
    @objc func refresh()  {
        // pieChart.build()
        // sideMenuViewController?.presentLeftMenuViewController()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

//extension UIColor {
//    public convenience init?(hexString: String) {
//        let r, g, b, a: CGFloat
//
//        if hexString.hasPrefix("#") {
//            let start = hexString.index(hexString.startIndex, offsetBy: 1)
//            let hexColor = String(hexString[start...])
//
//            if hexColor.count == 8 {
//                let scanner = Scanner(string: hexColor)
//                var hexNumber: UInt64 = 0
//
//                if scanner.scanHexInt64(&hexNumber) {
//                    r = CGFloat((hexNumber & 0xff000000) >> 24) / 255
//                    g = CGFloat((hexNumber & 0x00ff0000) >> 16) / 255
//                    b = CGFloat((hexNumber & 0x0000ff00) >> 8) / 255
//                    a = CGFloat(hexNumber & 0x000000ff) / 255
//
//                    self.init(red: r, green: g, blue: b, alpha: a)
//                    return
//                }
//            }
//        }
//
//        return nil
//    }
//    func hexStringToUIColor (hex:String) -> UIColor {
//        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
//
//        if (cString.hasPrefix("#")) {
//            cString.remove(at: cString.startIndex)
//        }
//
//        if ((cString.count) != 6) {
//            return UIColor.gray
//        }
//
//        var rgbValue:UInt32 = 0
//        Scanner(string: cString).scanHexInt32(&rgbValue)
//
//        return UIColor(
//            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
//            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
//            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
//            alpha: CGFloat(1.0)
//        )
//    }
//}
extension UIColor {
    public convenience init?(hexString: String)
    {
        let hex = hexString.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int = UInt32()
        Scanner(string: hex).scanHexInt32(&int)
        let a, r, g, b: UInt32
        switch hex.count {
        case 3: // RGB (12-bit)
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: // RGB (24-bit)
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: // ARGB (32-bit)
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(red: CGFloat(r) / 255, green: CGFloat(g) / 255, blue: CGFloat(b) / 255, alpha: CGFloat(a) / 255)
    }
}
class Data {
    var value:CGFloat
    var color:UIColor = UIColor.gray
    var label:String = ""
    
    init(myValue:CGFloat, myColor:UIColor, myLabel:String) {
        value = myValue
        color = myColor
        label = myLabel
    }
}

//MARK:- Custom Methods
//MARK:-

extension DashbordVC{
    
    func initalLoad() {
        
        self.navigationController?.isNavigationBarHidden = true
        
        // Initialize the Array
        attentionReqlist = ["Inspection", "Message", "Profile","Open Orders","Late Orders","Accept Orders","Revision Requested"]
        notificationcout = ["01","19","","10","21","03","08","08"]
        attentionReqlistimg = ["inspection", "message", "document","document","inspection", "message", "document","document"]
        backgroundColor = ["#ffa500", "008B8B", "94d60b","008B8B", "DC143C", "94d60b", "#ffa500"]
        items = [Int32(self.view.frame.size.width/2-15),Int32(self.view.frame.size.width/2-15),Int32(self.view.frame.size.width-15),Int32(self.view.frame.size.width/2-15),Int32(self.view.frame.size.width/2-15),Int32(self.view.frame.size.width/2-15),Int32(self.view.frame.size.width/2-15)]

        
        //Custome Cell Registraion
        self.AttentionRequiredCV.register(UINib(nibName: "ItemsCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "ItemsCollectionViewCell")
        
        //Initialize SearchBar
        ItemSearchBar.barTintColor = UIColor.clear
        ItemSearchBar.backgroundImage = UIImage()
        ItemSearchBar.tintAdjustmentMode = UIViewTintAdjustmentMode.normal
        
    }
    
    func configurePieChart()  {
        pieChart = MDRotatingPieChart(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.width))
        
        slicesData = [
            Data(myValue: 10, myColor: UIColor(red: 0.16, green: 0.73, blue: 0.61, alpha: 1), myLabel:"Party A"),
            Data(myValue: 15, myColor: UIColor(red: 0.23, green: 0.6, blue: 0.85, alpha: 1), myLabel:"Party B"),
            Data(myValue: 25, myColor: UIColor(red: 0.6, green: 0.36, blue: 0.71, alpha: 1), myLabel:"Party C"),
            Data(myValue: 20, myColor: UIColor(red: 0.46, green: 0.82, blue: 0.44, alpha: 1), myLabel:"Party D"),
            Data(myValue: 10, myColor: UIColor(red: 0.94, green: 0.79, blue: 0.19, alpha: 1), myLabel:"Party E"),
            Data(myValue: 5, myColor: UIColor(red: 0.89, green: 0.49, blue: 0.19, alpha: 1), myLabel:"Party F")]
        
        pieChart.delegate = self
        pieChart.datasource = self
        
        view.addSubview(pieChart)
        
        /*
         Here you can dig into some properties
         -------------------------------------
         */
        var properties = Properties()
        
        properties.smallRadius = 50
        properties.bigRadius = 100
        properties.expand = 25
        
        
        properties.displayValueTypeInSlices = .percent
        properties.displayValueTypeCenter = .label
        
        properties.fontTextInSlices = UIFont(name: "Arial", size: 10)!
        properties.fontTextCenter = UIFont(name: "Arial", size: 10)!
        
        properties.enableAnimation = true
        properties.animationDuration = 0.5
        
        
        let nf = NumberFormatter()
        nf.groupingSize = 3
        nf.maximumSignificantDigits = 2
        nf.minimumSignificantDigits = 2
        
        properties.nf = nf
        
        pieChart.properties = properties
        
        
        
        let title = UILabel(frame: CGRect(x: 0, y: view.frame.width, width: view.frame.width, height: 100))
        // title.text = "@xouuox\n\nMDRotatingPieChart demo \nclick on a slice, or drag the pie :)"
        title.textAlignment = .center
        title.numberOfLines = 4
        view.addSubview(title)
        
        //        let refreshBtn = UIButton(frame: CGRect(x: (view.frame.width-200)/2, y: view.frame.width+100, width: 200, height: 50))
        //        refreshBtn.setTitleColor(UIColor.white, for: UIControlState())
        //        refreshBtn.setTitle("Refresh", for: UIControlState())
        //        refreshBtn.addTarget(self, action: #selector(DashbordVC.refresh), for: UIControlEvents.touchUpInside)
        //        refreshBtn.backgroundColor = UIColor.lightGray
        //        view.addSubview(refreshBtn)
        
        
        
        self.navigationController?.navigationBar.tintColor = UIColor.blue
        
        //Set up navigation bar
        // let barItemFram = CGRect(x: 0, y: 0, width: 44, height: 44);
        
        
        
        
        
        // Add Side Menu
        // Configure The SideMenu
        
        //        leftSideMenuViewController  =  self.storyboard?.instantiateViewController(withIdentifier: KVSideMenu.leftSideViewController)
        
        //        rightSideMenuViewController =  self.storyboard?.instantiateViewController(withIdentifier: KVSideMenu.rightSideViewController)
        
        // Set default root
        //        self.changeSideMenuViewControllerRoot(KVSideMenu.RootsIdentifiers.initialViewController)
        
        // Set freshRoot value to true/false according to your roots managment polity. By Default value is false.
        // If freshRoot value is ture then we will always create a new instance of every root viewcontroller.
        // If freshRoot value is ture then we will reuse already created root viewcontroller if exist otherwise create it.
        
        // self.freshRoot = true
        
        // self.menuContainerView?.delegate = self
        
        
    }
}

//MARK:-  Button Action
//MARK:-

extension DashbordVC {
    
    @IBAction func tabOnMenu(_ sender: UIButton){
        sideMenuViewController?.presentLeftMenuViewController()
        print("click on side menu")
    }
    
}

//MARK:- CollectionView Methods
//MARK:-

extension DashbordVC: UICollectionViewDelegateFlowLayout, UICollectionViewDataSource{
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int{
        return 7
    }
    
    // The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell{
        let cell : ItemsCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "ItemsCollectionViewCell", for: indexPath) as! ItemsCollectionViewCell
        cell.lblName.text = attentionReqlist[indexPath.row]
        cell.lblCount.text = notificationcout[indexPath.row]
        cell.imgIcon.image = UIImage(named:attentionReqlistimg[indexPath.row])
        cell.Viewbg.backgroundColor = UIColor(hexString: backgroundColor[indexPath.row])

        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = items[indexPath.row]
        return CGSize(width: Int(width), height: Int(AttentionRequiredCV.frame.size.height/4.3))
    }

}

extension DashbordVC: UICollectionViewDelegate{
    
    public func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let objMessageVC = self.storyboard?.instantiateViewController(withIdentifier: "MessageListVC") as! MessageListVC
        self.navigationController?.pushViewController(objMessageVC, animated: true)
        
    }
}



