//
//  OrderDetailVC.swift
//  Exatech
//
//  Created by Anil on 19/03/18.
//  Copyright © 2018 Anil. All rights reserved.
//

import UIKit
//import ObjectMapper

class OrderDetailVC: BaseViewController {

    @IBOutlet weak var OrderListCV: UICollectionView!
    var attentionReqlist = [String]()
    var attentionReqlistimg = [String]()
    var notificationcout = [String]()
    
    @IBOutlet weak var InspDetailBGV: UIView!
    @IBOutlet weak var CustomerDetailBGV: UIView!
    @IBOutlet weak var ProductDetailBGV: UIView!
    @IBOutlet weak var BackgroundV: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        initaLoad()

        // Do any additional setup after loading the view.
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
//MARK:-  Button Action
//MARK:-

extension OrderDetailVC {
    
    @IBAction func tabOnMenu(_ sender: UIButton){
        sideMenuViewController?.presentLeftMenuViewController()
        print("click on side menu")
    }
    
}
//MARK:- Custom Methods
//MARK:-

extension OrderDetailVC{
    
    func initaLoad() {
        
        self.navigationController?.isNavigationBarHidden = true
        
        self.OrderListCV.register(UINib(nibName: "OrderCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "OrderCollectionViewCell")
        
        // Initialize the Array
        attentionReqlist = ["Inspection", "Message", "Profile","Open Orders","Late Orders","Accept Orders","Revision Requested"]
        notificationcout = ["01","19","","10","21","03","08","08"]
        attentionReqlistimg = ["inspection", "message", "document","document","inspection", "message", "document","document"]
        
        //SET Border
        self.BackgroundV.layer.borderWidth = 1
        self.BackgroundV.layer.borderColor = UIColor.lightGray.cgColor
        
        self.InspDetailBGV.layer.borderWidth = 1
        self.InspDetailBGV.layer.borderColor = UIColor.lightGray.cgColor
        
        self.CustomerDetailBGV.layer.borderWidth = 1
        self.CustomerDetailBGV.layer.borderColor = UIColor.lightGray.cgColor
        
        self.ProductDetailBGV.layer.borderWidth = 1
        self.ProductDetailBGV.layer.borderColor = UIColor.lightGray.cgColor
    }
}
//MARK:- CollectionView Methods
//MARK:-

extension OrderDetailVC: UICollectionViewDelegateFlowLayout, UICollectionViewDataSource{
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int{
        return 7
    }
    
    // The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell{
        let cell : OrderCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "OrderCollectionViewCell", for: indexPath) as! OrderCollectionViewCell
        cell.LblName.text = attentionReqlist[indexPath.row]
        cell.IcoImg.image = UIImage(named:attentionReqlistimg[indexPath.row])
        
        return cell
    }
    
}

extension OrderDetailVC: UICollectionViewDelegate{
    
    public func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let objMessageVC = self.storyboard?.instantiateViewController(withIdentifier: "MessageListVC") as! MessageListVC
        self.navigationController?.pushViewController(objMessageVC, animated: true)
        
    }
}
