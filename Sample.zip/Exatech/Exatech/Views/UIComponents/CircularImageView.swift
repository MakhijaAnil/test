//
//  CircularImageView.swift
//  BTV-Host
//
//  Created by Anil on 05/03/18.
//  Copyright © 2017 DigiMantra. All rights reserved.
//

import UIKit

class CircularImageView: UIImageView {
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        let cornerRadius: CGFloat = min(frame.height, frame.width) / 2.0
        layer.cornerRadius = cornerRadius
        layer.masksToBounds = true
        clipsToBounds = true
        contentMode = .scaleAspectFill
    }
}
