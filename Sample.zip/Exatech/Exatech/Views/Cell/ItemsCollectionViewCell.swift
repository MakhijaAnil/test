//
//  ItemsCollectionViewCell.swift
//  Exatech
//
//  Created by Admin on 11/04/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import UIKit

class ItemsCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var Viewbg: UIView!
    @IBOutlet weak var lblCount: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var imgIcon: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
