//
//  AccountTypeCVCell.swift
//  Exatech
//
//  Created by Admin on 18/04/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import UIKit

class AccountTypeCVCell: UICollectionViewCell {

    @IBOutlet weak var AccountImg: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
