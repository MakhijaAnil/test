//
//  ActivityListItemModel.swift
//  BTV-Coach
//
//  Created by Anil on 05/03/18.
//  Copyright © 2017 AppRoots.tech. All rights reserved.
//

import Foundation

struct ActivityListItemModel {
    var activity: ActivityModel
    var count: Int
}
