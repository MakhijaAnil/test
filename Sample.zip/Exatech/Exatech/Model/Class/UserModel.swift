//
//  UserModel.swift
//  BTV-Host
//
//  Created by Anil on 05/03/18.
//  Copyright © 2017 DigiMantra. All rights reserved.
//

import Foundation
import ObjectMapper
import CoreLocation

class UserModel: Mappable {
    var id: Int?
    var placeID: Int?
    var isActive: Int?
    var authKey: String?
    var username: String?
    var firstName: String?
    var lastName: String?
    var countryCode: String?
    var phone: String?
    var gender: String?
    var dateOfBirth: String?
    var email: String?
    var address: String?
    var city: String?
    var state: String?
    var country: String?
    var zipCode: String?
    var latitude: String?
    var longitude: String?
    var selectPlace: String?
    var selectPlaceID: Int?
    var languageSpoken: String?
    var introBlurb: String?
    var description: String?
    var websiteLink: String?
    var backgroundScreening:String?
    var coachType:Int?
    
    var profileImage: PhotoModel?
    var activities: [ActivityModel]?
   // var activityInsurances: [ActivityInsuranceModel]?
   // var bussinessDetail: BussinessDetailModel?
    var galleryPhoto: [PhotoModel]?
   // var customContent: [CustomContentModel]?

    
    
    var coordinates: CLLocationCoordinate2D? {
        guard let latitude = latitude, let longitude = longitude else {
            return nil
        }
        
        return CLLocationCoordinate2D(latitude: Double(latitude)!, longitude: Double(longitude)!)
    }
    
    var fullname:String? {
        return "\(firstName ?? "") \(lastName ?? "")"
    }
    
    
    init() {
    }
    
    required init?(map: Map) {}
    
    // Mappable
    func mapping(map: Map) {
        id <- map["user.user_id"]
        placeID <- map["place_id"]
        isActive <- map["user.is_active"]
        authKey <- map["user.authKey"]
        username <- map["user.username"]
        firstName <- map["user.firstname"]
        lastName <- map["user.lastname"]
        countryCode <- map["user.code"]
        phone <- map["user.mobile"]
        gender <- (map["user.gender"])
        dateOfBirth <- (map["user.dob"])
        email <- map["user.email"]
        address <- map["address"]
        city <- map["city"]
        state <- map["state"]
        country <- map["country"]
        latitude <- map["latitude"]
        longitude <- map["longitude"]
        zipCode <- map["zipcode"]
        introBlurb <- map["dynamic_fields.intro_blurb_host"]
        description <- map["dynamic_fields.description"]
        websiteLink <- map["dynamic_fields.website"]
        languageSpoken <- map["dynamic_fields.language_spoken"]
        profileImage <- map["photos.profile"]
        activities <- map["activities"]
//        activityInsurances <- map["activity_insurarances"]
//        customContent <- map["place.additional_content"]
//        galleryPhoto <- map["photos.other_images"]
//        bussinessDetail <- map["business_detail"]
        backgroundScreening <- map["dynamic_fields.screening_status"]
        
  //      coachType <- map["user.coach_type"]
        coachType <- (map["in_house"], IntTransform())

        selectPlaceID <- (map["coaching_place_id"], IntTransform())
        selectPlace <- map["coaching_place_name"]
        
//        print(customContent)
//
//        if customContent == nil {
//            customContent <- map["dynamic_fields.additional_content"]
//        }
        
        if introBlurb == nil {
            introBlurb <- map["dynamic_fields.intro_blurb"]
        }
    }
}



