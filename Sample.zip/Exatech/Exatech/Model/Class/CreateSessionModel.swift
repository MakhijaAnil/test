//
//  CreateSessionModel.swift
//  BTV-Host
//
//  Created by Anil on 05/03/18
//  Copyright © 2017 DigiMantra. All rights reserved.
//

import Foundation

class SessionDetailModel {
    
//    var sessionDescribe:SessionDescribeModel?
//    var sessionActivity:SessionActivityModel?
//    var sessionGroupType:Int?
//    var sessionShedule:SeesionScheduleModel?
//    var sessionDiffucltyType:Int?
//    var sessionPlace:SessionPlaceModel?
//    var sessionCoach:SessionCoachModel?
//    var sessionCostModel:[SessionCostModel]?
//    var sessionMembershipPlane:[SessionMembershipModel]?
//    var sessionPhotos:SessionPhotosModel?
    
}
