//
//  CreatePlaceModel.swift
//  BTV-Host
//
//  Created by Anil on 05/03/18.
//  Copyright © 2017 DigiMantra. All rights reserved.
//

import Foundation

class CreatePlaceModel {
    
    var id:String?
    var placeDescribe:PlaceDescribeModel?
//    var placeBussinesDetail:PlaceBussinessDetailModel?
//    var placeBussinesAddress:PlaceBussinessAddressModel?
//    var placeActivity:[ActivityModel]?
//    var placeAmentities:[PlaceAmenitiesModel]?
//    var placeSchedule:[DefineScheduleModel]?
//    var placePhotos:SessionPhotosModel?

}





