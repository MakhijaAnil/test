//
//  ActivityModel.swift
//  BTV-Coach
//
//  Created by Anil on 05/03/18.
//  Copyright © 2016 AppRoots.tech. All rights reserved.
//


import ObjectMapper

class ActivityModel: Mappable {
    var id: Int?
    var title: String?
    var detail: String?
    var icon: String?
    var insurance:Bool?
    
    init() {
    }
    
    required init?(map: Map) {}
    
    func mapping(map: Map) {
        
        id <- (map["activity_id"], IntTransform())
        title <- map["activity_name"]
        detail <- map["activity_description"]
        icon <- map["image_url.enabled"]

        
        if insurance == nil {
            var insuranceInt = Int()
            insuranceInt <- map["insurance"]
            
            if insuranceInt == 1 {
                insurance = true
            } else {
                insurance = false
            }
        }
        
        if icon == nil, let imageJSONString = map.JSON["image_name"] as? String {
            if let json = imageJSONString.parseJSONString,
                let enabledImage = json.value(forKeyPath: "images.enabled") as? String,
                let id = id {
                icon = App.URLs.imageActivityBaseURL + "\(id)/" + enabledImage
            }
        }
    }
    
    func getTitle() -> String {
        if let title = title {
            return title
        }
        return ""
    }
    
    func getIcon() -> String {
        if let icon = icon {
            return icon
        }
        return ""
    }
}

