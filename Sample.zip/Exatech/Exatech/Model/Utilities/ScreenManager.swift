//
//  ScreenManager.swift
//  BTV-Ambassador
//
//  Created by Anil on 13/02/17.
//  Copyright © 2017 DigiMantra. All rights reserved.
//

import Foundation
import UIKit
import AKSideMenu

class ScreenManager {
    // hide the initializer
    private init() {}
    
    class func setAsMainViewController(_ viewController: UINavigationController) {
        let window = UIApplication.shared.keyWindow
        window?.rootViewController = viewController
    }
    
    class func mainStoryboard() -> UIStoryboard {
        return UIStoryboard(name: "Main", bundle: nil)
    }
    
    
    class func getRootViewController() -> UINavigationController {
        
        let sideMenuViewController = getMenuViewController()
        var contentViewController: UIViewController
        
        contentViewController = getDashboardViewController()
        
        let akSideMenu = AKSideMenu(contentViewController: contentViewController, leftMenuViewController: sideMenuViewController, rightMenuViewController: nil)
        
        akSideMenu.menuPreferredStatusBarStyle = .lightContent
        akSideMenu.contentViewShadowColor = UIColor.black
        akSideMenu.contentViewShadowOffset = CGSize(width: 0, height: 0)
        akSideMenu.contentViewShadowOpacity = 0.6
        akSideMenu.contentViewShadowRadius = 12
        akSideMenu.contentViewInPortraitOffsetCenterX = 60.0
        akSideMenu.contentViewShadowEnabled = true
        akSideMenu.bouncesHorizontally = false
        
        return embedNavigationController(viewController: akSideMenu)
    
      /*  if UserDefaults.isUserLoggedIn() {
            
            if UserDefaults.getUser()?.isActive == 2 {
                contentViewController = getDashboardViewController()            } else if UserDefaults.getUser()?.isActive == 1 {
                contentViewController = getDashboardViewController()
            } else {
                contentViewController = getLoginViewController()
                return embedNavigationController(viewController: contentViewController)
            }
            
            let akSideMenu = AKSideMenu(contentViewController: contentViewController, leftMenuViewController: sideMenuViewController, rightMenuViewController: nil)
            
            akSideMenu.menuPreferredStatusBarStyle = .lightContent
            akSideMenu.contentViewShadowColor = UIColor.black
            akSideMenu.contentViewShadowOffset = CGSize(width: 0, height: 0)
            akSideMenu.contentViewShadowOpacity = 0.6
            akSideMenu.contentViewShadowRadius = 12
            akSideMenu.contentViewInPortraitOffsetCenterX = 60.0
            akSideMenu.contentViewShadowEnabled = true
            akSideMenu.bouncesHorizontally = false
           
            return embedNavigationController(viewController: akSideMenu)
            
        } else {
            
            contentViewController = getLoginViewController()
            return embedNavigationController(viewController: contentViewController)
            
        }*/

    }
    
    class func getRootViewControllerForSpecificControllerWithMenu(controller:UIViewController) -> UINavigationController {
        
        let sideMenuViewController = getMenuViewController()
        var contentViewController: UIViewController
        contentViewController = controller
        
        let akSideMenu = AKSideMenu(contentViewController: contentViewController, leftMenuViewController: sideMenuViewController, rightMenuViewController: nil)
        
        akSideMenu.menuPreferredStatusBarStyle = .lightContent
        akSideMenu.contentViewShadowColor = UIColor.black
        akSideMenu.contentViewShadowOffset = CGSize(width: 0, height: 0)
        akSideMenu.contentViewShadowOpacity = 0.6
        akSideMenu.contentViewShadowRadius = 12
        akSideMenu.contentViewInPortraitOffsetCenterX = 60.0
        akSideMenu.contentViewShadowEnabled = true
        akSideMenu.bouncesHorizontally = false
        
        return embedNavigationController(viewController: akSideMenu)

    }
    
   class func embedNavigationController(viewController:UIViewController) -> UINavigationController {
        let navController = UINavigationController(rootViewController: viewController)
        navController.isNavigationBarHidden = true
        return navController
    }
    
    
    class func getMenuViewController() -> MenuViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: MenuViewController.className) as! MenuViewController
    }
    
    class func getDashboardViewController() -> DashbordVC {
        return mainStoryboard().instantiateViewController(withIdentifier: DashbordVC.className) as! DashbordVC
    }
    class func getMyOrderViewController() -> OrderDetailVC {
        return mainStoryboard().instantiateViewController(withIdentifier: OrderDetailVC.className) as! OrderDetailVC
    }
   
    class func getLoginViewController() -> ViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: ViewController.className) as! ViewController
    }
    
    /*class func getSignUpViewController() -> SignUpViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: SignUpViewController.className) as! SignUpViewController
    }
    
    class func getManageProfileViewController() -> ManageProfileViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: ManageProfileViewController.className) as! ManageProfileViewController
    }
    
    class func getFavoriteCoachViewController() -> FavoriteCoachViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: FavoriteCoachViewController.className) as! FavoriteCoachViewController
    }
    
    class func getSettingAndPreferencesViewController() -> SettingAndPreferencesViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: SettingAndPreferencesViewController.className) as! SettingAndPreferencesViewController
    }
    
    class func getContactSupportViewController() -> ContactSupportViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: ContactSupportViewController.className) as! ContactSupportViewController
    }
    
    class func getActivityListViewController() -> ActivityListViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: ActivityListViewController.className) as! ActivityListViewController
    }
    
    class func getActivitySelectionViewController() -> ActivitySelectionViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: ActivitySelectionViewController.className) as! ActivitySelectionViewController
    }
    
    class func getCoachListViewController() -> CoachListViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: CoachListViewController.className) as! CoachListViewController
    }
    
    class func getCoachDetailViewController() -> CoachDetailViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: CoachDetailViewController.className) as! CoachDetailViewController
    }
    
    class func getCoachProfileSetUpViewController() -> CoachProfileSetUpViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: CoachProfileSetUpViewController.className) as! CoachProfileSetUpViewController
    }
    
    class func getCustomContentFormViewController() -> CustomContentFormViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: CustomContentFormViewController.className) as! CustomContentFormViewController
    }
    
    class func getInsuranceFormPopupViewController() -> InsuranceFormPopupViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: InsuranceFormPopupViewController.className) as! InsuranceFormPopupViewController
    }
    
    class func getTermsAndConditionsViewController() -> TermsAndConditionsViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: TermsAndConditionsViewController.className) as! TermsAndConditionsViewController
    }
    
    class func getTermsAndConditionsDetailViewController() -> TermsAndConditionsDetailViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: TermsAndConditionsDetailViewController.className) as! TermsAndConditionsDetailViewController
    }
    
    class func getPostSignupViewController() -> PostSignupViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: PostSignupViewController.className) as! PostSignupViewController
    }
    
    class func getBussinessDetailFormViewController() -> BussinessDetailFormViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: BussinessDetailFormViewController.className) as! BussinessDetailFormViewController
    }
    
    class func getDefineYourScheduleViewController() -> DefineYourScheduleViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: DefineYourScheduleViewController.className) as! DefineYourScheduleViewController
    }
    
    class func getDefineScheduleSlotViewController() -> DefineScheduleSlotViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: DefineScheduleSlotViewController.className) as! DefineScheduleSlotViewController
    }
    
    class func getGalleryViewController() -> GalleryViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: GalleryViewController.className) as! GalleryViewController
    }
    
    class func getMessageListViewController() -> MessageListViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: MessageListViewController.className) as! MessageListViewController
    }
    
    class func getNotificationListViewController() -> NotificationListViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: NotificationListViewController.className) as! NotificationListViewController
    }
    
    class func getQRCodeScannerViewController() -> QRCodeScannerViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: QRCodeScannerViewController.className) as! QRCodeScannerViewController
    }
    
    class func getDescribeSessionViewController() -> DescribeSessionViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: DescribeSessionViewController.className) as! DescribeSessionViewController
    }
    
    class func getCreateSessionViewController() -> CreateSessionViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: CreateSessionViewController.className) as! CreateSessionViewController
    }
    
    class func getChooseSessionActivityViewController() -> ChooseSessionActivityViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: ChooseSessionActivityViewController.className) as! ChooseSessionActivityViewController
    }
    
    class func getChooseSessionTypeViewController() -> ChooseSessionTypeViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: ChooseSessionTypeViewController.className) as! ChooseSessionTypeViewController
    }
    
    class func getActivityDurationViewController() -> ActivityDurationViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: ActivityDurationViewController.className) as! ActivityDurationViewController
    }
    
    class func getDescribeSessionScheduleViewController() -> DescribeSessionScheduleViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: DescribeSessionScheduleViewController.className) as! DescribeSessionScheduleViewController
    }
    
    class func getSessionDifficultyViewController() -> SessionDifficultyViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: SessionDifficultyViewController.className) as! SessionDifficultyViewController
    }
    
    class func getWhereSessionViewController() -> WhereSessionViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: WhereSessionViewController.className) as! WhereSessionViewController
    }
    
    class func getSessionSpecificDateViewController() -> SessionSpecificDateViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: SessionSpecificDateViewController.className) as! SessionSpecificDateViewController
    }
    
    class func getSessionGeneralScheduleViewController() -> SessionGeneralScheduleViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: SessionGeneralScheduleViewController.className) as! SessionGeneralScheduleViewController
    }
    
    class func getSessionCostViewController() -> SessionCostViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: SessionCostViewController.className) as! SessionCostViewController
    }
    
    class func getSessionPhotosViewController() -> SessionPhotosViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: SessionPhotosViewController.className) as! SessionPhotosViewController
    }
    
    class func getWhereDistanceSessionViewController() -> WhereDistanceSessionViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: WhereDistanceSessionViewController.className) as! WhereDistanceSessionViewController
    }

    
    class func getSessionCostDetailViewController() -> SessionCostDetailViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: SessionCostDetailViewController.className) as! SessionCostDetailViewController
    }
    
    class func getSessionChooseCoachViewController() -> SessionChooseCoachViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: SessionChooseCoachViewController.className) as! SessionChooseCoachViewController
    }
    
    class func getSessionCoachListViewController() -> SessionCoachListViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: SessionCoachListViewController.className) as! SessionCoachListViewController
    }
    
    class func getSessionConfirmationViewController() -> SessionConfirmationViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: SessionConfirmationViewController.className) as! SessionConfirmationViewController
    }
    
    class func getCreatedSessionViewController() -> CreatedSessionViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: CreatedSessionViewController.className) as! CreatedSessionViewController
    }
    
    class func getCreateMembershipViewController() -> CreateMembershipViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: CreateMembershipViewController.className) as! CreateMembershipViewController
    }
    
    class func getMembershipSpecificSessionViewController() -> MembershipSpecificSessionViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: MembershipSpecificSessionViewController.className) as! MembershipSpecificSessionViewController
    }
    
    class func getBlockListViewController() -> BlockListViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: BlockListViewController.className) as! BlockListViewController
    }
    
    class func getBlockHostViewController() -> BlockCoachViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: BlockCoachViewController.className) as! BlockCoachViewController
    }
    
    class func getCreatePlaceViewController() -> CreatePlaceViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: CreatePlaceViewController.className) as! CreatePlaceViewController
    }
    
    class func getDescribePlaceViewController() -> DescribePlaceViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: DescribePlaceViewController.className) as! DescribePlaceViewController
    }
    
    class func getPlaceBussinessDetailViewController() -> PlaceBussinessDetailViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: PlaceBussinessDetailViewController.className) as! PlaceBussinessDetailViewController
    }
    
    class func getPlaceAddressViewController() -> PlaceAddressViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: PlaceAddressViewController.className) as! PlaceAddressViewController
    }
    
    class func getChoosebussinessPlacePhotosViewController() -> ChoosebussinessPlacePhotosViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: ChoosebussinessPlacePhotosViewController.className) as! ChoosebussinessPlacePhotosViewController
    }
    
    class func getChooseBussinessActivitiesViewController() -> ChooseBussinessActivitiesViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: ChooseBussinessActivitiesViewController.className) as! ChooseBussinessActivitiesViewController
    }
    
    class func getChoosePlaceAmenitiesViewController() -> ChoosePlaceAmenitiesViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: ChoosePlaceAmenitiesViewController.className) as! ChoosePlaceAmenitiesViewController
    }
    
    class func getChooseSessionMembershipViewController() -> ChooseSessionMembershipViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: ChooseSessionMembershipViewController.className) as! ChooseSessionMembershipViewController
    }
    
    class func getPlaceScheduleViewController() -> PlaceScheduleViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: PlaceScheduleViewController.className) as! PlaceScheduleViewController
    }
    
    class func getPlaceConfirmationViewController() -> PlaceConfirmationViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: PlaceConfirmationViewController.className) as! PlaceConfirmationViewController
    }
    
    class func getUserCustomSessionViewController() -> UserCustomSessionViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: UserCustomSessionViewController.className) as! UserCustomSessionViewController
    }
    
    class func getCoachCustomSessionViewController() -> CoachCustomSessionViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: CoachCustomSessionViewController.className) as! CoachCustomSessionViewController
    }
    
    class func getScheduleViewController() -> ScheduleViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: ScheduleViewController.className) as! ScheduleViewController
    }
    
    class func getHostCustomSessionViewController() -> HostCustomSessionViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: HostCustomSessionViewController.className) as! HostCustomSessionViewController
    }
    
    class func getProposalViewController() -> ProposalViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: ProposalViewController.className) as! ProposalViewController
    }
    
    class func getProposalSubmittedViewController() -> ProposalSubmittedViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: ProposalSubmittedViewController.className) as! ProposalSubmittedViewController
    }
    
    class func getOpenSessionListViewController() -> OpenSessionListViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: OpenSessionListViewController.className) as! OpenSessionListViewController
    }
    
    class func getOpenSessionDetailViewController() -> OpenSessionDetailViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: OpenSessionDetailViewController.className) as! OpenSessionDetailViewController
    }
    
    class func getSendMessageViewController() -> SendMessageViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: SendMessageViewController.className) as! SendMessageViewController
    }
    
    class func getReportViewController() -> ReportViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: ReportViewController.className) as! ReportViewController
    }
    
    class func getMyEarningsViewController() -> MyEarningsViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: MyEarningsViewController.className) as! MyEarningsViewController
    }
    
    
    class func getTransactionsHistoryViewController() -> TransactionsHistoryViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: TransactionsHistoryViewController.className) as! TransactionsHistoryViewController
    }
    
    class func getMapViewController() -> MapViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: MapViewController.className) as! MapViewController
    }
    
    
    class func getPayoutDetailViewController() -> PayoutDetailViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: PayoutDetailViewController.className) as! PayoutDetailViewController
    }
    
    class func getTransactionDetailViewControler() -> TransactionDetailViewController {
        return mainStoryboard().instantiateViewController(withIdentifier:TransactionDetailViewController.className) as! TransactionDetailViewController
    }
    
    class func getRatingAndReviewController() -> RatingAndReviewController {
        return mainStoryboard().instantiateViewController(withIdentifier:RatingAndReviewController.className) as! RatingAndReviewController
    }
    
    class func getPaymentMethodViewController() -> PaymentMethodViewController {
        return mainStoryboard().instantiateViewController(withIdentifier:PaymentMethodViewController.className) as! PaymentMethodViewController
    }
    
    class func getInHouseCoachListViewController() -> InHouseCoachListViewController {
        return mainStoryboard().instantiateViewController(withIdentifier:InHouseCoachListViewController.className) as! InHouseCoachListViewController
    }
    
    class func getMembershipListViewController() -> MembershipListViewController {
        return mainStoryboard().instantiateViewController(withIdentifier:MembershipListViewController.className) as! MembershipListViewController
    }
    
    class func getPlaceListViewController() -> PlaceListViewController {
        return mainStoryboard().instantiateViewController(withIdentifier:PlaceListViewController.className) as! PlaceListViewController
    }
    
    class func getSessionListViewController() -> SessionListViewController {
        return mainStoryboard().instantiateViewController(withIdentifier:SessionListViewController.className) as! SessionListViewController
    }*/
    
    
}
