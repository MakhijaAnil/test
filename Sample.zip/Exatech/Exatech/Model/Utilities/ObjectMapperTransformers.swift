//
//  ObjectMapperTransformers.swift
//  BTV-Coach
//
//  Created by Anil on 05/03/18.
//  Copyright © 2017 AppRoots.tech. All rights reserved.
//

import Foundation
import ObjectMapper

class IntTransform: TransformType {
    typealias Object = Int
    typealias JSON = Int

    func transformFromJSON(_ value: Any?) -> Object? {
        if let value = value {
            return Int("\(value)")
        }
        return nil
    }

    func transformToJSON(_ value: Object?) -> JSON? {
        return value
    }
}

class BoolTransform: TransformType {
    typealias Object = Bool
    typealias JSON = String

    func transformFromJSON(_ value: Any?) -> Object? {
        if let value = value as? String {
            return value == "1"
        } else if let value = value as? Int {
            return value == 1
        }
        return nil
    }

    func transformToJSON(_ value: Object?) -> JSON? {
        if let value = value {
            return value ? "1" : "0"
        }

        return nil
    }
}

class BTVDateTransform: TransformType {
    typealias Object = Date
    typealias JSON = String
    
    func transformFromJSON(_ value: Any?) -> Object? {
        if let value = value as? String {
            return DateTimeFormatter.serverDate(from: value)
        }
        
        return nil
    }
    
    func transformToJSON(_ value: Object?) -> JSON? {
        if let value = value {
            return DateTimeFormatter.serverDateString(from: value)
        }
        
        return nil
    }
}

class BTVDateTimeTransform: TransformType {
    typealias Object = Date
    typealias JSON = String
    
    func transformFromJSON(_ value: Any?) -> Object? {
        if let value = value as? String {
            return DateTimeFormatter.serverDateTime(from: value)
        }
        
        return nil
    }
    
    func transformToJSON(_ value: Object?) -> JSON? {
        if let value = value {
            return DateTimeFormatter.serverDateTimeString(from: value)
        }
        
        return nil
    }
}

//class GenderTransform: TransformType {
//    typealias Object = GenderPickerView.Gender
//    typealias JSON = String
//    
//    func transformFromJSON(_ value: Any?) -> Object? {
//        if let value = value as? String {
//            if value == "m" || value == Object.male.rawValue {
//                return Object.male
//            } else if value == "f" || value == Object.female.rawValue {
//                return Object.female
//            }
//        }
//        
//        return nil
//    }
//    
//    func transformToJSON(_ value: Object?) -> JSON? {
//        if let gender = value {
//            return gender.rawValue
//        }
//        
//        return nil
//    }
//}


