//
//  StringExtension.swift
//  BTV-Coach
//
//  Created by Anil on 05/03/18.
//  Copyright © 2017 AppRoots.tech. All rights reserved.
//

import Foundation

extension String {
    var parseJSONString: AnyObject? {
        let data = self.data(using: .utf8, allowLossyConversion: false)

        if let jsonData = data {
            return try? JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers) as AnyObject
        } else {
            return nil
        }
    }
}
