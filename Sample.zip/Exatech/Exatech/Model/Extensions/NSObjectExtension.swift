//
//  NSObjectExtension.swift
//  BTV-Host
//
//  Created by Anil on 05/03/18.
//  Copyright © 2017 DigiMantra. All rights reserved.
//

import Foundation

extension NSObject {
    var className: String {
        return String(describing: type(of: self))
    }
    
    class var className: String {
        return String(describing: self)
    }
}
