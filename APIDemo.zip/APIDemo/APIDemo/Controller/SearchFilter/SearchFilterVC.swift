

import UIKit

class SearchFilterVC: UIViewController {
  
    var bankListimg = [String]()

    @IBOutlet weak var AccountListCV: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        initaLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

//MARK:- Custome Method
//MARK:-

extension SearchFilterVC{
    
    func initaLoad(){
        
        self.AccountListCV.register(UINib(nibName: "AccountTypeCVCell", bundle: nil), forCellWithReuseIdentifier: "AccountTypeCVCell")
        // Initialize the Array
        bankListimg = ["america", "capitec", "citi-logo","first-niagara","us_bank_"]
    }
}

//MARK:-  Button Action
//MARK:-

extension SearchFilterVC {
    
    @IBAction func tabOnMenu(_ sender: UIButton){
        sideMenuViewController?.presentLeftMenuViewController()
        print("click on side menu")
    }
    
}

//MARK:- CollectionView Methods
//MARK:-

extension SearchFilterVC: UICollectionViewDelegateFlowLayout, UICollectionViewDataSource{
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int{
        return 4
    }
    
    // The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell{
        let cell : AccountTypeCVCell = collectionView.dequeueReusableCell(withReuseIdentifier: "AccountTypeCVCell", for: indexPath) as! AccountTypeCVCell
        cell.AccountImg.image = UIImage(named:bankListimg[indexPath.row])
        
        return cell
    }
    
}

extension SearchFilterVC: UICollectionViewDelegate{
    
    public func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//        let objMessageVC = self.storyboard?.instantiateViewController(withIdentifier: "MessageListVC") as! MessageListVC
//        self.navigationController?.pushViewController(objMessageVC, animated: true)
        
    }
}
