

import UIKit

class AccountTypeCVCell: UICollectionViewCell {

    @IBOutlet weak var AccountImg: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
