

import UIKit

class MenuTableViewCell: UITableViewCell {

    @IBOutlet weak var iconImageView: UIImageView!
    @IBOutlet weak var titleLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func configure(for rowIndex:Int ,menuItem: MenuItemModel) {
        
        var showSeperatorLimit = Int()
        
//        if UserDefaults.getUser()?.isActive == 2 {
//            showSeperatorLimit = 1
//        } else {
//            showSeperatorLimit = 5
//        }
        
        iconImageView.image = menuItem.icon
        self.separatorInset = UIEdgeInsets(top: 0, left: self.bounds.size.width, bottom: 0, right: 0)
        titleLbl.font = UIFont(name: App.Fonts.SFUIDisplay.Light, size: 15)
        
        /*if rowIndex < showSeperatorLimit {
            iconImageView.image = menuItem.icon
            self.separatorInset = UIEdgeInsetsMake(0, 20, 0, 20)
            titleLbl.font = UIFont(name: App.Fonts.SFUIDisplay.Regular, size: 16)
        } else {
            iconImageView.image = menuItem.icon
            self.separatorInset = UIEdgeInsetsMake(0, self.bounds.size.width, 0, 0)
            titleLbl.font = UIFont(name: App.Fonts.SFUIDisplay.Light, size: 15)
        }*/
        titleLbl.text = menuItem.title
    }
}
