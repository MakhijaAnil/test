

import UIKit

class ItemsCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var Viewbg: UIView!
    @IBOutlet weak var lblCount: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var imgIcon: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
