

import UIKit

class OrderCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var IcoImg: UIImageView!
    @IBOutlet weak var LblName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
   
    func configure(for rowIndex:Int )//,menuItem: MenuItemModel
    {
        
       // var showSeperatorLimit = Int()
        
        //        if UserDefaults.getUser()?.isActive == 2 {
        //            showSeperatorLimit = 1
        //        } else {
        //            showSeperatorLimit = 5
        //        }
        
       // IcoImg.image = menuItem.icon
       // self.separatorInset = UIEdgeInsetsMake(0, self.bounds.size.width, 0, 0)
        LblName.font = UIFont(name: App.Fonts.SFUIDisplay.Light, size: 10)
        LblName.numberOfLines = 2
        /*if rowIndex < showSeperatorLimit {
         iconImageView.image = menuItem.icon
         self.separatorInset = UIEdgeInsetsMake(0, 20, 0, 20)
         titleLbl.font = UIFont(name: App.Fonts.SFUIDisplay.Regular, size: 16)
         } else {
         iconImageView.image = menuItem.icon
         self.separatorInset = UIEdgeInsetsMake(0, self.bounds.size.width, 0, 0)
         titleLbl.font = UIFont(name: App.Fonts.SFUIDisplay.Light, size: 15)
         }*/
       // LblName.text = menuItem.title
    }

}
