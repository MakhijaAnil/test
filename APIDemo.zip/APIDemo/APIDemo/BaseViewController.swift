

import UIKit
import SystemConfiguration
import MBProgressHUD
import Jelly
import SwiftValidator
import Crashlytics

class BaseViewController: UIViewController {
    
    var jellyAnimator: JellyAnimator?
    fileprivate var progressHUD: MBProgressHUD?
    var user: UserModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("ViewDidLoad: " + self.className)
        
        self.automaticallyAdjustsScrollViewInsets = false
        self.navigationController?.isNavigationBarHidden = false
        
        if UserDefaults.isUserLoggedIn() {
            user = UserDefaults.getUser()
        }
        
        Answers.logSearch(withQuery:"ViewDidLoad:" + self.className,customAttributes: nil)
    }
}

//MARK:- Validation
//MARK:-

extension BaseViewController {

    func isValidEmail(testStr:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }
    
//    func isRoutingNumberValid(routingNumber:String) -> Bool {
//        
//        var result = Int()
//        
//        for (index,value) in routingNumber.characters.enumerated() {
//            
//            let value = Int(String(value))
//            
//            if index == 0 || index == 3 || index == 6 {
//                result = result + (value! * 3)
//            } else if index == 1 || index == 4 || index == 7 {
//                
//                result = result + (value! * 7)
//                
//            } else if index == 2 || index == 5 || index == 8 {
//                result = result + (value! * 1)
//            }
//        }
//        
//        if result % 10 == 0 {
//            return true
//        } else {
//            return false
//        }
//    }
}

//MARK:- StatusBar
//MARK:-

extension BaseViewController {
    
    func setStatusBarBackgroundColor(color: UIColor) {
        guard let statusBar = UIApplication.shared.value(forKeyPath: "statusBarWindow.statusBar") as? UIView else { return }
        statusBar.backgroundColor = color
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return UIStatusBarStyle.lightContent
    }
}

//MARK:- Alert
//MARK:-

extension BaseViewController {

    func showAlert(title: String?, message: String?, viewController:UIViewController) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .default, handler: nil)
        
        alertController.addAction(action)
        viewController.present(alertController, animated: true, completion: nil)
    }
    
    func showAlert(validationErrors: [(Validatable, ValidationError)]) {
        let sortedErrors = validationErrors.sorted { (item1, item2) -> Bool in
            guard let field1 = item1.1.field as? UIView,
                let field2 = item2.1.field as? UIView else {
                    return false
            }
            
            let field1Frame = view.convert(field1.bounds, from: field1)
            let field2Frame = view.convert(field2.bounds, from: field2)
            
            if field1Frame.minY == field2Frame.minY {
                return field1Frame.minX < field2Frame.minX
            }
            
            return field1Frame.minY < field2Frame.minY
        }
        
        for (_, error) in sortedErrors {
            showAlert(title: App.Name, message: "\(error.errorMessage)", viewController: self)
            break
        }
    }
    
    func showAlertForLogout(title: String?, message: String?, viewController:UIViewController) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        alert.addAction(
            UIAlertAction(
                title: "OK",
                style: .default,
                handler: { _ in
//                    UserDefaults.clearUserData()
//                    ScreenManager.setAsMainViewController(ScreenManager.getRootViewController())
            })
        )
        
      //  alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
        viewController.present(alert, animated: true, completion: nil)
    }
}

//MARK:- UITextField 
//MARK:-

extension UITextField {
    
    func underlined(){
        let border = CALayer()
        let width = CGFloat(1.0)
        border.borderColor = UIColor.lightGray.cgColor
        border.frame = CGRect(x: 0, y: self.frame.size.height - width, width:  self.frame.size.width, height: self.frame.size.height)
        border.borderWidth = width
        self.layer.addSublayer(border)
        self.layer.masksToBounds = true
    }
    
    func peding(){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 30, height: 0))
        self.leftView = paddingView
        self.leftViewMode = .always
    }
    
    func setimage(SideImage: UIImage?){
            
            let leftAddView = UIView.init(frame: CGRect(x: 0, y: 5, width: 30, height: self.frame.size.height-5))
            let leftimageView = UIImageView.init(frame: CGRect(x:0, y: 0, width: 30, height: 30))//Create a imageView for left side.
            leftimageView.image = SideImage
            leftAddView.addSubview(leftimageView)
            self.leftView = leftAddView
        self.leftViewMode = UITextField.ViewMode.always
        }
}
//MARK:- Internet Connection Check
//MARK:-

extension BaseViewController {

    func isConnectedToNetwork() -> Bool {
        var zeroAddress = sockaddr_in()
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        
        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }
        
        var flags = SCNetworkReachabilityFlags()
        if !SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) {
            return false
        }
        
        let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
        let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
        return (isReachable && !needsConnection)
    }
}

//MARK:-  Activity Indicator
//MARK:-

extension BaseViewController {
    
    func startIndicator(viewController:UIViewController) {
        
        progressHUD?.hide(animated: true)
        progressHUD = nil
        progressHUD = MBProgressHUD.showAdded(to: viewController.view, animated: true)
        progressHUD?.animationType = .zoom
        progressHUD?.label.text = "Loading"

    }
    
    func startIndicatorForImage(viewController:UIViewController) {
        
        progressHUD?.hide(animated: true)
        progressHUD = nil
        progressHUD = MBProgressHUD.showAdded(to: viewController.view, animated: true)
        progressHUD?.animationType = .zoom
        progressHUD?.mode = .determinate
        progressHUD?.label.text = "uploading"
        
    }
    
    func stopIndicator(viewController:UIViewController) {
        progressHUD?.hide(animated: true)
        progressHUD = nil

    }
}



//MARK:-  Jelly Popup
//MARK:-

extension BaseViewController {
    
    func showPopup(_ viewController: UIViewController, size: CGSize) {
//        jellyAnimator = JellyAnimator(presentation: JellyPresentationManager.getSlideInPopupAnimation(targetSize: size))
//        jellyAnimator?.prepare(viewController: viewController)
//        DispatchQueue.main.async {
//            self.present(viewController, animated: true, completion: nil)
        }
    }
    
    func showPopupSlideInAnimation(_ viewController: UIViewController) {
//        jellyAnimator = JellyAnimator(presentation: JellyPresentationManager.getSlideInPresentationAnimation())
//        jellyAnimator?.prepare(viewController: viewController)
//        self.present(viewController, animated: true, completion: nil)
 //   }
}
