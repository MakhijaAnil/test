

import Foundation
import ObjectMapper

class PhotoModel: Mappable {
    var id: Int?
    var name: String?
    var path: String?
    var original: String?
    var thumb: String?
    
    var image: UIImage?
    
    var completePath: String? {
        if let path = path {
            return App.URLs.imageBaseURL + path
        }
        
        return ""
    }
    
    init() {}
    
    required init?(map: Map) {}
    
    func mapping(map: Map) {
        id <- map["photos_id"]
        name <- map["photo_title"]
        path <- map["photo_path"]
        original <- map["image_url.orig"]
        thumb <- map["image_url.thumb"]
    }
    
    var isNew: Bool {
        return image != nil
    }
}
