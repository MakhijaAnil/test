

import Foundation

struct ActivityListItemModel {
    var activity: ActivityModel
    var count: Int
}
