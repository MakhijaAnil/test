
import Foundation
import UIKit

struct MenuItemModel {
    var icon : UIImage?
    var title : String
}

extension MenuItemModel {

  static func getMenuItem() -> [MenuItemModel] {
        
    var menuItem = [MenuItemModel]()
    menuItem.append(MenuItemModel(icon: UIImage(named: "dashbord"), title: "Dashboard"))
    menuItem.append(MenuItemModel(icon: UIImage(named: "myorder"), title: "My Orders"))
    menuItem.append(MenuItemModel(icon: UIImage(named: "outofoffice"), title: "Out Of Office"))
    menuItem.append(MenuItemModel(icon: UIImage(named: "Attention"), title: "Attention Required"))
    menuItem.append(MenuItemModel(icon: UIImage(named: "About"), title: "About Exatech"))
    menuItem.append(MenuItemModel(icon: UIImage(named: "ContactUs"), title: "Contact Us"))
    
   /* if UserDefaults.getUser()?.isActive == 2 {
        
        menuItem.append(MenuItemModel(icon: UIImage(named: "dashboardGreen"), title: "Profile"))
        menuItem.append(MenuItemModel(icon: nil, title: "Contact Support"))
        
    } else {
        
        menuItem.append(MenuItemModel(icon: UIImage(named: "dashbord"), title: "Dashboard"))
        menuItem.append(MenuItemModel(icon: UIImage(named: "myorder"), title: "My Orders"))
        menuItem.append(MenuItemModel(icon: UIImage(named: "outofoffice"), title: "Out Of Office"))
        menuItem.append(MenuItemModel(icon: UIImage(named: "Attention"), title: "Attention Required"))
        menuItem.append(MenuItemModel(icon: UIImage(named: "About"), title: "About Exatech"))
        menuItem.append(MenuItemModel(icon: UIImage(named: "ContactUs"), title: "Contact Us"))
        
    }*/
    
    
    return menuItem
    }
}
