

import Foundation

class CreatePlaceModel {
    
    var id:String?
    var placeDescribe:PlaceDescribeModel?
//    var placeBussinesDetail:PlaceBussinessDetailModel?
//    var placeBussinesAddress:PlaceBussinessAddressModel?
//    var placeActivity:[ActivityModel]?
//    var placeAmentities:[PlaceAmenitiesModel]?
//    var placeSchedule:[DefineScheduleModel]?
//    var placePhotos:SessionPhotosModel?

}





