

import Foundation

class PlaceDescribeModel {
    
    var name:String?
    var description:String?
   // var additionalContent:[CustomContentModel]?

}
