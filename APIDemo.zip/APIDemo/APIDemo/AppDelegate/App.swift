

import Foundation
import Alamofire
import UIKit
import SwiftValidator

struct AppValidationRules {
    static var PasswordRules: [Rule] {
        return [
            RequiredRule(message: "Please enter a password"),
            RegexRule(regex: "^(?=.*?[A-Z])(?=.*?[0-9])(?=.*?[a-z]).*?$", message: "Password must contain at least one uppercase, one lowercase and one numeric character"),
            MinLengthRule(length: 8, message: "Password must have a minimum length of at least 8 characters"),
            MaxLengthRule(length: App.PasswordCharacterLimit, message: "Password must have a maximum length of \(App.PasswordCharacterLimit) characters")
        ]
    }
}

struct App {

    static let PasswordCharacterLimit: Int = 20

    static let Name: String = "Bodies.TV"
    static let SiteURL: String = "http://www.bodies.com"

    static let DateFormatDMY: String = "dd-MM-yyyy"
    static let DateFormat: String = "MM-dd-yyyy"

    static let TimeFormat: String = "h:mm a"
    static let FullDateFormat: String = "EEEE, MM d, yyyy"
    static let FullDateTimeFormat: String = "EEEE, MM-dd-yyyy HH:mm:ss"

    static let ServerDateFormat: String = "yyyy-MM-dd"
    static let ServerTimeFormat: String = "HH:mm:ss"
    static let ServerDateTimeFormat: String = "yyyy-MM-dd HH:mm:ss"

    struct Fonts {
        struct Signika {
            static let Regular = "Signika-Regular"
            static let Light = "Signika-Light"
            static let Bold = "Signika-Bold"
            static let SemiBold = "Signika-Semibold"
        }
        struct Roboto {
            static let Regular = "Roboto-Regular"
            static let Light = "Roboto-Light"
            static let Bold = "Roboto-Bold"
            static let Medium = "Roboto-Medium"
            static let Black = "Roboto-Black"
            static let Thin = "Roboto-Thin"
        }
        struct SFUIDisplay {
            static let Regular = "SFUIDisplay-Regular"
            static let Light = "SFUIDisplay-Light"
            static let Bold = "SFUIDisplay-Bold"
        }
    }

    struct Colors {

        struct Gradient {
            static let topColor = UIColor(red: 94.0/255.0, green: 50.0/255.0, blue: 144.0/255.0, alpha: 1.0).cgColor
            static let midColor = UIColor(red: 100.0/255.0, green: 164.0/255.0, blue: 209.0/255.0, alpha: 1.0).cgColor
            static let bottomColor = UIColor(red: 80.0/255.0, green: 194.0/255.0, blue: 208.0/255.0, alpha: 1.0).cgColor
        }

        static let Pink = UIColor(red: 254/255, green: 40/255, blue: 81/255, alpha: 1)
        static let LighterGray = UIColor(red: 243.0/255.0, green: 243.0/255.0, blue: 243.0/255.0, alpha: 1)
        static let DarkerGray = UIColor(red: 74.0/255.0, green: 74.0/255.0, blue: 74.0/255.0, alpha: 1)
        static let DarkerGrayWithOpacity = UIColor(red: 74.0/255.0, green: 74.0/255.0, blue: 74.0/255.0, alpha: 0.7)
        static let DarkGray = UIColor(red: 137.0/255.0, green: 137.0/255.0, blue: 137.0/255.0, alpha: 1)
        static let Purple = UIColor(red: 106.0/255.0, green: 53.0/255.0, blue: 111.0/255.0, alpha: 1)
        static let GreenMix = UIColor(red: 76.0/255.0, green: 198.0/255.0, blue: 165.0/255.0, alpha: 1)
        static let SkyBlue = UIColor(red: 29.0/255.0, green: 175.0/255.0, blue: 221.0/255.0, alpha: 1)

        static let BorderColor = UIColor(red: 200.0/255.0, green: 199.0/255.0, blue: 204.0/255.0, alpha: 1.0)
        static let LightBackgroundColor = UIColor(red: 244.0/255.0, green: 244.0/255.0, blue: 244.0/255.0, alpha: 1.0)
        static let golden = UIColor(red: 250.0/255.0, green: 137.0/255.0, blue: 0.0/255.0, alpha: 1.0)

    }

    struct Devices {
        static let isIphone4 =  UIScreen.main.bounds.height < 568 ? true:false
        static let isIphone5 =  UIScreen.main.bounds.height == 568 ? true:false
        static let isIphone6_7 = UIScreen.main.bounds.height == 667 ? true:false
        static let isIphone6_7p = UIScreen.main.bounds.height == 736 ? true:false
        static let isIpad = UIScreen.main.bounds.height > 736 ? true:false

    }


    struct URLs {
        
//        static let baseURL: String = "http://api.livestage.bodiesapp.com"
//       static let baseURL: String = "http://api.stage.bodiesapp.com"
//        static let baseURL: String = "http://35.166.59.196:8086"
        //static let baseURL: String = "https://api.qa.bodiesapp.com/"
         static let baseURL: String = "https://api.test.bodiesapp.com"
        
        static let insuranceURL: String = "http://www.cphins.com/bodies/"
        static let googleApiKey: String = "AIzaSyAWJ2Yn3q7Hy0QsC76Wo_EQUSD6xJocrYg"
        
        static let googleMapGeocode = "https://maps.googleapis.com/maps/api/geocode/json"
        static let googleSearchPlace = "https://maps.googleapis.com/maps/api/place/autocomplete/json"

        static let imageBaseURL: String = "http://cdn.bodiesapp.com/uploads/"
        static let imageActivityBaseURL: String = "http://cdn.bodiesapp.com/uploads/activity/"
        static let imagePlaceHolderURL: String = "Placeholder.jpg"
        static let version: String = "v1"

        static let login = "users/host-login"
        static let signup = "users/host-signup"
        static let forgotPassword = "users/requestpasswordreset"
        static let resendActivationEmail = "users/resend-activation"
        static let profile = "users/host-profile"
        static let coachProfile = "users/in-house-coach-profile"
        static let createCoach = "host/create-coach"
        static let getCoaches = "host/activitycoaches"
        static let getPlaces = "host/places"
        static let getPlaceDetail = "host/place-detail"
        static let ContactSupport = "contact/support"
        static let hostActivities = "host/activites"
        static let activityList = "activity/activitylist"
        static let getAgencies = "site/agencies"
        static let coachFavourite = "favorite/coach"
        static let coachUnFavourite = "favorite/coach-unfavor"
        static let getFavouriteCoach = "host/favoritecoaches"
        static let getInHouseCoach = "host/inhousecoaches"
        static let schedule = "host/schedule"
        static let getMessages = "notification/list-message"
        static let registerDeviceToken = "user-device/ios"
        static let createSession = "host/create-session"
        static let getSessionList = "host/session-listing"
        static let getSessionDetail = "host/detail"
        static let getCreatedSession = "host-created-sessions"
        static let createPlace = "host/create-place"
        static let getSession = "host/get-session"
        static let createMembership = "host/create-membership"
        static let getBlockedCoachList = "host/block-coach-list"
        static let getSearchedUnBlockedCoach = "host/coach-search"
        static let blockCoach = "host/block-coach"
        static let unblockCoach = "host/un-block-coach"
        static let getDashboard = "host/dashboard"
        static let getAmenity = "amenity/list"
        static let getMembershipPlan = "host/get-membership-plans"
        static let getScheduleList = "host/your-schedule-stable"
        static let getScheduleSessionDetail = "host/session-detail"
        static let getOpenSessionRequestList = "host/activity-session-request"
        static let getOpenCustomSessionList = "host/activity-open-session-request"
        static let submitProposel = "host/host-proposal"
        static let myProposel = "host/my-proposal"
        static let rejectProposal = "host/reject-proposal"
        static let acceptProposal = "host/accept-proposal"
        static let markCompleteSession = "host/update-session-status"
        static let sendMessage = "host/send-message"
        static let myEarning = "host/my-earnings"
        static let transactionHistory = "host/transaction-history"
        static let transactionDetail = "host/earning-session?"
        static let accountDetail = "host/save-payment-method"
        static let requestSchedule = "host/session-schedules"
    }

    enum DeepLinks: String {
        case verifyUser = "verify_user"
        case invite = "invite"

        static func allDeepLinks() -> [DeepLinks] {
            return [.verifyUser,.invite]
        }
    }

    enum Events: String {
        case UserSignedIn = "NSNotificationUserSignedIn"
        case LocationAccessAuthorisationChanged = "NSNotificationLocationAccessAuthorizationChanged"
        case UserLocationUpdated = "NSNotificationUserLocationUpdated"
        case UserProfileUpdated = "NSNotificationUserProfileUpdated"
        case NotificationReceived = "NSNotificationNotificationReceived"
        case NotificationRead = "NSNotificationNotificationRead"

        var NSNotificationName: NSNotification.Name {
            return NSNotification.Name(rawValue)
        }
    }
}
